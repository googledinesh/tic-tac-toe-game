// --- Sounds ---
const sounds = {
  x: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/sfx-x.mp3'], volume: 0.6 }),
  o: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/sfx-o.mp3'], volume: 0.6 }),
  win: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/sfx-win.mp3'], volume: 0.7 }),
  lose: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/sfx-lose.mp3'], volume: 0.7 }),
  draw: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/sfx-draw.mp3'], volume: 0.7 }),
  bgm: new Howl({ src: ['https://cdn.jsdelivr.net/gh/AIwolverine/tic-tac-toe-assets/bgm.mp3'], volume: 0.4, loop: true })
};
let musicOn = false;

// --- Game Variables ---
let board = Array(9).fill(null);
let playerMark = "X";
let aiMark = "O";
let turn = "X";
let gameActive = true;
let difficulty = "easy";
let scores = { X: 0, O: 0, Draw: 0 };

// --- DOM ---
const $board = document.getElementById("board");
const $status = document.getElementById("status");
const $restart = document.getElementById("restart");
const $difficulty = document.getElementById("difficulty");
const $playerMark = document.getElementById("playerMark");
const $scoreX = document.getElementById("score-x");
const $scoreO = document.getElementById("score-o");
const $scoreDraw = document.getElementById("score-draw");
const $musicToggle = document.getElementById("music-toggle");

// --- Utility ---
const winningCombos = [
  [0,1,2], [3,4,5], [6,7,8],
  [0,3,6], [1,4,7], [2,5,8],
  [0,4,8], [2,4,6]
];

function renderBoard() {
  $board.innerHTML = "";
  board.forEach((cell, idx) => {
    const div = document.createElement("div");
    div.classList.add("cell");
    if (cell) {
      div.classList.add("filled");
      if (cell === "O") div.classList.add("o");
      div.textContent = cell;
    }
    if (!gameActive || cell) div.classList.add("disabled");
    div.onclick = () => handleCellClick(idx);
    $board.appendChild(div);
  });
}

function handleCellClick(idx) {
  if (!gameActive || board[idx] || turn !== playerMark) return;
  board[idx] = playerMark;
  playSfx(playerMark);
  renderBoard();
  checkGameEnd();
  if (gameActive) {
    turn = aiMark;
    updateStatus();
    setTimeout(aiMove, 400);
  }
}

function updateStatus(msg) {
  if (msg) { $status.textContent = msg; return; }
  if (!gameActive) return;
  $status.textContent = (turn === playerMark)
    ? `Your turn (${playerMark})`
    : `AI's turn (${aiMark})`;
}

function checkGameEnd() {
  const winner = getWinner(board);
  if (winner) {
    gameActive = false;
    updateScore(winner);
    renderBoard();
    if (winner === playerMark) {
      updateStatus("You win! 🎉");
      sounds.win.play();
    } else {
      updateStatus("AI wins! 😈");
      sounds.lose.play();
    }
    return true;
  }
  if (board.every(cell => cell)) {
    gameActive = false;
    updateScore("Draw");
    updateStatus("It's a draw! 🤝");
    sounds.draw.play();
    return true;
  }
  return false;
}

function updateScore(who) {
  if (who === "Draw") scores.Draw++;
  else scores[who]++;
  $scoreX.textContent = `X: ${scores.X}`;
  $scoreO.textContent = `O: ${scores.O}`;
  $scoreDraw.textContent = `Draws: ${scores.Draw}`;
}

function getWinner(bd) {
  for (const combo of winningCombos) {
    const [a,b,c] = combo;
    if (bd[a] && bd[a] === bd[b] && bd[b] === bd[c]) return bd[a];
  }
  return null;
}

function aiMove() {
  if (!gameActive) return;
  let move;
  if (difficulty === "easy") move = aiRandomMove();
  else if (difficulty === "medium") move = aiMediumMove();
  else move = aiMinimaxMove();
  if (move !== null) {
    board[move] = aiMark;
    playSfx(aiMark);
    renderBoard();
    checkGameEnd();
    if (gameActive) {
      turn = playerMark;
      updateStatus();
    }
  }
}

function aiRandomMove() {
  const avail = board.map((c,i) => c ? null : i).filter(x => x !== null);
  if (avail.length === 0) return null;
  return avail[Math.floor(Math.random() * avail.length)];
}

function aiMediumMove() {
  // Try to win
  for (let i=0; i<9; i++) {
    if (!board[i]) {
      board[i] = aiMark;
      if (getWinner(board) === aiMark) { board[i] = null; return i; }
      board[i] = null;
    }
  }
  // Block player
  for (let i=0; i<9; i++) {
    if (!board[i]) {
      board[i] = playerMark;
      if (getWinner(board) === playerMark) { board[i] = null; return i; }
      board[i] = null;
    }
  }
  // Take center
  if (!board[4]) return 4;
  // Take a corner
  for (let idx of [0,2,6,8]) if (!board[idx]) return idx;
  // Random
  return aiRandomMove();
}

function aiMinimaxMove() {
  let bestScore = -Infinity, move = null;
  for (let i=0; i<9; i++) {
    if (!board[i]) {
      board[i] = aiMark;
      let score = minimax(board, 0, false);
      board[i] = null;
      if (score > bestScore) { bestScore = score; move = i; }
    }
  }
  return move;
}

function minimax(bd, depth, isMaximizing) {
  const winner = getWinner(bd);
  if (winner === aiMark) return 10 - depth;
  if (winner === playerMark) return depth - 10;
  if (bd.every(cell => cell)) return 0;

  if (isMaximizing) {
    let maxEval = -Infinity;
    for (let i=0; i<9; i++) {
      if (!bd[i]) {
        bd[i] = aiMark;
        let eval = minimax(bd, depth+1, false);
        bd[i] = null;
        maxEval = Math.max(maxEval, eval);
      }
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (let i=0; i<9; i++) {
      if (!bd[i]) {
        bd[i] = playerMark;
        let eval = minimax(bd, depth+1, true);
        bd[i] = null;
        minEval = Math.min(minEval, eval);
      }
    }
    return minEval;
  }
}

function playSfx(mark) {
  if (mark === "X") sounds.x.play();
  else if (mark === "O") sounds.o.play();
}

function restartGame() {
  board = Array(9).fill(null);
  turn = "X";
  gameActive = true;
  if (playerMark === "O") turn = "O";
  renderBoard();
  updateStatus();
  if (turn === aiMark) setTimeout(aiMove, 500);
}

function changeDifficulty() {
  difficulty = $difficulty.value;
  restartGame();
}

function changePlayerMark() {
  playerMark = $playerMark.value;
  aiMark = (playerMark === "X" ? "O" : "X");
  restartGame();
}

function toggleMusic() {
  musicOn = !musicOn;
  if (musicOn) {
    sounds.bgm.play();
    $musicToggle.style.background = "#ff5858";
  } else {
    sounds.bgm.stop();
    $musicToggle.style.background = "#43cea2";
  }
}

// --- Event Listeners ---
$restart.onclick = restartGame;
$difficulty.onchange = changeDifficulty;
$playerMark.onchange = changePlayerMark;
$musicToggle.onclick = toggleMusic;

// --- Init ---
renderBoard();
updateStatus();